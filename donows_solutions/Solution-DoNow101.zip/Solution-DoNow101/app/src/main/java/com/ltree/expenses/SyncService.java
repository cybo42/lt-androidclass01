package com.ltree.expenses;


import android.app.Activity;
import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;

import com.ltree.expenses.data.Expense;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;

/**
 * An {@link android.app.IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p/>
 *
 */
public class SyncService extends IntentService {
    private static final String TAG="SyncService";
	private static int NOTIFICATION_ID = 1;

    public SyncService() {
        super("SyncService");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "onCreate() called");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Log.i(TAG, "Processing Started");

		/** Default action is to save to the Web service using JSON */
		boolean exportToCsvFile = false;
		// Create a notification that the service started OK
		createNotification();

		Log.i(TAG, "Service Started");

        // If there is no data associated with the Intent, sets the data to the default URI, which
        // accesses a list of expenses.
        if (intent.getData() == null) {
            intent.setData(Expense.ExpenseItem.CONTENT_URI);
        }

        Bundle extras = intent.getExtras();
        if(null != extras){
        	//  Note that the flag indicating what action the service should take is retrieved here (nothing to change)
        	exportToCsvFile = extras.getBoolean(Constants.EXPENSE_EXTRA_EXPORT_TO_CSV);

        }

        //  Note the expense data is being retrieved from the Content Provider as a cursor
		ContentResolver resolver =getContentResolver();
        Cursor cursor = resolver.query(
            	intent.getData(), // Use the default content URI for the provider.
                Expense.ExpenseItem.FULL_PROJECTION, //PROJECTION,                       // Return the note ID and title for each note.
                null,                             // No where clause, return all records.
                null,                             // No where clause, therefore no where column values.
                Expense.ExpenseItem.DEFAULT_SORT_ORDER  // Use the default sort order.
            );

        //  Call the helper method in Expense.Helper which converts the cursor to an array of expenses
        // TODO 10 Note that we are converting the cursor into an arrray of expenses (nothing to change)
        Expense[] expenses = Expense.Helper.getExpensesFromCursor(cursor);


        if(exportToCsvFile){
    		// Work out where to write the file (from the Intent Extras)
            String fileName = resolveFileNameForExpenses(intent);
            //  pass the array of expenses to the writeExpensesToCsvFile helper method
         // You will work on this method next
            writeExpensesToCsvFile(fileName, expenses);

        } else {
        	try{
	        	//This will be invoked if the extra data (Constants.EXPENSE_EXTRA_EXPORT_TO_CSV) is not supplied
	        	// TODO 11 Call the toJSON() method to convert the expenses array into JSON
	        	String jsonData = toJSON(expenses);
	        	// TODO 12 pass the jsonData into the putToWebService method
	        	postToWebService(jsonData);
        	}catch (JSONException e) {
    			Log.e(TAG,"Failed to convert expenses to JSON",e);
    		}  catch (Exception e) {
    			Log.e(TAG,"Error communicating with service. Check the server is running and that you named the JSON element correctly! [expense]" ,e);
    		}

        }
        if(null != cursor){
        		// Close the cursor to release any resources
        	cursor.close();
        }
		Log.i(TAG, "Processing finished");
	}


	/**
	 * Send expenses to Web service as JSON data
	 * @param expenses the array of expenses to return
	 */

	private String toJSON(Expense[] expenses) throws JSONException {

			// TODO 21 Use Expense.Helper.expenseArrayToJSON() to convert our expenses to a JSON array
			JSONArray jExpenses = Expense.Helper.expenseArrayToJSON(expenses);
			// TODO 22 Create a new JSONObject to represent the outer wrapper or root of our JSON data
			JSONObject jsonRoot = new JSONObject();
			// TODO 23 put the JSON expenses array into the jsonRoot as a property called expense
			jsonRoot.put("expense", jExpenses);
			// TODO 24 return the JSON data as a String
			return jsonRoot.toString();


	}


	/**
	 *
	 * @param msgBody
	 * @param uri
	 * @throws java.net.URISyntaxException
	 * @throws java.io.IOException
	 * @throws org.apache.http.client.ClientProtocolException
	 * @throws Exception
	 */
	public void postToWebService(String msgBody) throws URISyntaxException, ClientProtocolException, IOException  {

	   	 // TODO 31 *******  Set the IP address of localhost on the Windows machine where the service is running
		URI serviceUri = new URI("http://10.0.2.2:8080/ExpensesServer/rest/ExpenseServer/putExpenses");

		// TODO 32 Create a new HttpPost instance around the supplied service uri
        HttpPost postRequest = new HttpPost(serviceUri);
        // TODO 33 Add the the "content-type" header to the request, set the value to application/json
        postRequest.addHeader("content-type", "application/json");
        // TODO 34 add the JSON message body to the request as a new StringEntity (msgBody)
        ResponseHandler<String> handler = new BasicResponseHandler();

        // TODO 35 Create an instance of the DefaultHttpClient
        DefaultHttpClient httpclient = new DefaultHttpClient();

        // TODO 36 Use the client to execute a request passing the HttpPost and ResponseHandler as parameters
        String result = httpclient.execute(postRequest, handler);

        Log.i(TAG, "Put to Service. Result: " + result);

        // TODO 37 Shutdown the HttpClient (Hint: getConnectionManager())
        httpclient.getConnectionManager().shutdown();


    }



	private boolean writeExpensesToCsvFile(String fileName, Expense[] expenses)
	{
		boolean success = false;
		PrintWriter pw = null;

		//  Get the state of the external storage (remove the null!)
		// HINT: See chapter 5
		String state = Environment.getExternalStorageState();

		// Test that the state is Environment.MEDIA_MOUNTED (accessible and writable)
		// Hint: don't forget that state is a String (use equals() to compare)
		if(state.equals(Environment.MEDIA_MOUNTED )){
			try {
				// Get the File object representing the Public Downloads area
				// Hint: use a method on Environment
				File baseDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);

				// Ensure the directories in the path are actually created
				baseDir.mkdirs();


				// Create the file name we will use to write the CSV file
				// by appending the fileName to the baseDir
				// Hint: fileName is a parameter to the method you are working in
				File fullFileName = new File(baseDir, fileName);



				Log.d(TAG, "Outputting csv to: " + fullFileName.getAbsolutePath());
				//  Create a new PrintWriter to write the file (use the fullFileName )
				pw = new PrintWriter(fullFileName);


				// Pass the expenses array to Expense.Helper.expenseArrayToCsv then
				// use the PrintWriter to write the data to the CSV file
				// Hint: you may need to convert the returned StringBuilder to a string
				pw.write(Expense.Helper.expenseArrayToCsv(expenses).toString());

				success = true;
			} catch (IOException e) {
				e.printStackTrace();
				Log.e(TAG, "Failed to save expenses in service. Details:", e);
			} finally {
				if(null != pw){
					// close the PrintWriter
                    pw.close();
				}
			}
		}
		return success;
	}

	/**
	 * Helper method to set either a default file name or use one passed in with the intent
	 * @param intent
	 * @return the file name to write to
	 */
	private static String resolveFileNameForExpenses(Intent intent) {
		String fileName = Constants.DEFAULT_CSV_FILENAME; // set a default file name
        Bundle extras = intent.getExtras();
        if(null != extras ){
	        String tmpFName = extras.getString(Constants.EXPENSE_EXTRA_FILENAME);
	        if(null != tmpFName){
	        	fileName = tmpFName;
	        }
        }
		return fileName;
	}

	/** Creates a simple notification to indicate that the service has started */
	private void createNotification(){
		String msgSvcStarted = getResources().getString(R.string.svc_str_started);
		// Get the NotificationManager
		NotificationManager notManager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
		// Create a Notification
		Notification notification = new Notification(R.drawable.ic_app,msgSvcStarted,System.currentTimeMillis());
		// Add an Intent to the Notification. NB: Using a Dummy Activity which does nothing when selected
		Intent notificationIntent = new Intent(this, DummyActivity.class);
		// Create the PendingIntent
		PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
		// Flags so the Notification is cancelled once clicked
		notification.flags |= Notification.FLAG_AUTO_CANCEL;
		// Set the content
		notification.setLatestEventInfo(this, msgSvcStarted, msgSvcStarted, contentIntent);
		// Fire the notification
		notManager.notify(NOTIFICATION_ID, notification);

	}

	/** Dummy class to allow a notification to be created which does not actually do anything! */
	class DummyActivity extends Activity{
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			finish();
		}
    }
}
